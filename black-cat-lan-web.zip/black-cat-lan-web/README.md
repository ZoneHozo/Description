# BLACK CAT LAN🐈‍⬛

黒猫が主人公のジャングルランナーゲーム(React + Three.js + Tone.js)。

## 友達に公開する手順(GitHub Pages)

### 1. パソコンに準備する

- [Node.js](https://nodejs.org/)(18以上)をインストールしていない場合はインストール
- [GitHub](https://github.com/) のアカウントを作成していない場合は作成

### 2. このフォルダをGitHubリポジトリにする

1. GitHubで新しいリポジトリを作成する(例: `black-cat-lan`)
   - Public(公開)にする(友達がアクセスできるように)
   - README等は追加しない(空のリポジトリでOK)
2. このフォルダをパソコンにダウンロードし、ターミナル(コマンドプロンプト)で以下を実行:

```bash
cd black-cat-lan-web
git init
git add .
git commit -m "first commit"
git branch -M main
git remote add origin https://github.com/【あなたのユーザー名】/black-cat-lan.git
git push -u origin main
```

### 3. リポジトリ名に合わせて設定を1箇所直す

`vite.config.js` の `base` を、作ったリポジトリ名に合わせて書き換えます。

```js
base: "/black-cat-lan/",  // リポジトリ名が違う場合はここを変更
```

変更したら、コミットしてpushし直してください。

```bash
git add vite.config.js
git commit -m "fix base path"
git push
```

### 4. 依存パッケージをインストールしてビルド

```bash
npm install
npm run build
```

`dist` フォルダにゲーム一式が生成されます。

### 5. GitHub Pagesに公開する

一番簡単な方法(`gh-pages` パッケージを使用):

```bash
npm run deploy
```

初回はGitHubのリポジトリ設定 → 「Pages」で、公開元(Source)が `gh-pages` ブランチになっているか確認してください。

数分後、以下のURLでアクセスできるようになります:

```
https://【あなたのユーザー名】.github.io/black-cat-lan/
```

このURLを友達に送れば、ブラウザだけで遊べます。

## 注意点

- **BGM**: ブラウザの自動再生制限のため、スタートボタンを押した後に音が鳴ります。
- **ランキング**: スイカゲームのように、そのブラウザを開いている間だけ有効なランキングです。ページを閉じたり再読み込みすると消えます(誰かと共有されるものではありません)。
- **ローカルでの動作確認**: `npm run dev` を実行すると、公開前に手元のパソコンで動作確認できます。

## 技術構成

- React 18
- Three.js(3D描画)
- Tone.js(BGM生成・再生)
- Vite(ビルドツール)
