import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";

// GitHub Pagesで公開する場合、リポジトリ名に合わせて base を変更してください。
// 例: リポジトリ名が "black-cat-lan" なら base: "/black-cat-lan/"
export default defineConfig({
  plugins: [react()],
  base: "/black-cat-lan/",
});
