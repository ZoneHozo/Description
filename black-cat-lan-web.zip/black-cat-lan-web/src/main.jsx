import React from "react";
import ReactDOM from "react-dom/client";
import JungleRunner from "./JungleRunner.jsx";

ReactDOM.createRoot(document.getElementById("root")).render(
  <React.StrictMode>
    <JungleRunner />
  </React.StrictMode>
);
